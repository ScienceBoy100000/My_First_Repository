﻿using System.Globalization;

namespace calc_revisited;
// Teamwork mit Dominik Adam und Helene Redl

class Program
{
    static int HowMany()    //How many numbers do we wanna read?
    {
        while (true)    //we wanna repeat this, try again and again
        {
            // Ask the user how many numbers they want to enter.
            Console.Write("How many numbers do you want to enter? ");
            int howMany = int.Parse(Console.ReadLine());  //we could use TryParse, but we have to only restructure

            // Sanity check.
            if (howMany <= 0)
            {
                Console.WriteLine("Please enter a number > 0.");
                continue;
            }

            return howMany;
        }
    }
    static float[] WhatNumbers(int number)   //What numbers do we wanna read?
    {
        // Read in those numbers.
        float[] numbers = new float[number];

        for (int i = 0; i < number; i++)
        {
            Console.Write($"Number #{i + 1}: ");
            numbers[i] = float.Parse(Console.ReadLine());
        }

        return numbers;
    }
    static string WhatOps() //What operation do we wanna do?
    {
        // Ask the user which operation should be performed.
        // If the user enters an illegal operation, we just
        // ask again.
        string op = "";
        do
        {
            Console.Write("Which operation should be performed (+, -, *)? ");
            op = Console.ReadLine();
        } while (op != "+" && op != "-" && op != "*");

        return op;
    }
    static float Calc(float[] numbers, string operation)    //Calculate the result.
    {
        // Perform the calculation.
        // For the initial value of our result, we simply use
        // the first number the user has entered.
        // This removes the need to choose different neutral
        // values for addition (0), multiplication (1) etc.
        float result = numbers[0];

        for (int i = 1; i < numbers.Length; i++)
        {
            switch (operation)
            {
                case "+":
                    result += numbers[i];
                    break;
                case "-":
                    result -= numbers[i];
                    break;
                case "*":
                    result *= numbers[i];
                    break;
            }
        }

        return result;
    }

    static void Main(string[] args)
    {
        // We want to endlessly repeat the whole program ...
        while (true)
        {
            int count = HowMany();  //Define counter as the outcome of the method "HowMany"

            float[] numbers = WhatNumbers(count);   //Define numbers as the outcome of the method "WhatNumbers"

            string operation = WhatOps();   //Define operation as the outcome of the method "WhatOps"

            Console.WriteLine($"Result: {Calc(numbers, operation)}");   //Print the result of "Calc"
        }
    }
}
