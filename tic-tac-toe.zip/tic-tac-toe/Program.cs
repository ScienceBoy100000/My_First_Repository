﻿namespace tic_tac_toe;
// Teamwork mit Dominik Adam und Helene Redl

//Just for lazyness
//This lets me write "C" instead of "Console"
using System;
using System.Reflection.Metadata;
using C = System.Console;

class Program
{
    //1. Prints the board
    static void PrintBoard(string[,] board)
    {
        C.WriteLine();  //just for space
        C.WriteLine("  0:  1:  2:");
        C.WriteLine($"0: {board[0, 0]} | {board[0, 1]} | {board[0, 2]}"); //first row
        C.WriteLine($"  {new string('-', 11)}");   //divider
        C.WriteLine($"1: {board[1, 0]} | {board[1, 1]} | {board[1, 2]}"); //second row
        C.WriteLine($"  {new string('-', 11)}");   //divider
        C.WriteLine($"2: {board[2, 0]} | {board[2, 1]} | {board[2, 2]}"); //third row
        C.WriteLine();  //just for space
    }

    //2. Turn of Player "O"
    static void TurnO(string[,] board)
    {
        //2.1 Define coordinates
        int x = 0;
        int y = 0;

        //2.2 Ask for player input
        while (true)
        {          
            //2.2.1 Get input
            C.WriteLine("It's O's turn.");
            C.Write("What row? ");
            bool trueRow = int.TryParse(C.ReadLine(), out x);
            C.Write("What column? ");
            bool trueColumn = int.TryParse(C.ReadLine(), out y);

            //2.2.2 Sanity Check
            if (trueRow == true && trueColumn == true && 0 <= x && x <= 2 && 0 <= y && y <= 2 && board[x, y] == " ")
            {
                break;
            }

            C.WriteLine();  //just for space
            C.WriteLine("Try again please.");
        }

        //2.3 Put an "O" on the board
        board[x, y] = "O";
    }

    //3. Turn of Player "X"
    static void TurnX(string[,] board)
    {
        //3.1 Define coordinates
        int x = 0;
        int y = 0;

        //3.2 Ask for player input
        while (true)
        {
            //3.2.1 Get input
            C.WriteLine("It's X's turn.");
            C.Write("What row? ");
            bool trueRow = int.TryParse(C.ReadLine(), out x);
            C.Write("What column? ");
            bool trueColumn = int.TryParse(C.ReadLine(), out y);

            //3.2.2 Sanity Check
            //If x and y are correct and the slot has not been filled then go on.
            if (trueRow == true && trueColumn == true && 0 <= x && x <= 2 && 0 <= y && y <= 2 && board[x, y] == " ")
            {
                break;
            }

            C.WriteLine();  //just for space
            C.WriteLine("Try again please.");
        }

        //3.3 Put an "O" on the board
        board[x, y] = "X";
    }

    //4. Victory Conditions
    static bool Victory(string[,] board)
    {
        //4.0. Make a victory state
        bool victory = false;

        //4.1. Check the rows
        for (int i = 0; i <= 2; i++)
        {
            //watch for spaces!
            if (board[i, 0] != " " && board[i, 0] == board[i, 1] && board[i, 1] == board[i, 2])
            {
                victory = true;
            }
        }

        //4.2. Check the columns
        for (int i = 0; i <= 2; i++)
        {
            if (board[0, i] != " " && board[0, i] == board[1, i] && board[1, i] == board[2, i])
            {
                victory = true;
            }
        }

        //4.3 Check the diagonals
        if (board[0, 0] != " " && board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
        {
            victory = true;
        }
        else if (board[0, 2] != " " && board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
        {
            victory = true;
        }

        return victory;
    }

    static void Main(string[] args)
    {
        //0. Make a victory state
        bool victory = false;

        while (victory == false)
        {
            //1. Define Board
            int row = 3;    //how many rows
            int column = 3; //how many columns
            string[,] board = new string[row, column];  //make a multidimensional array with rows and columns

            //2. Fill the board with empty spaces
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    board[i, j] = " ";
                }
            }

            //3. Print the starter board
            PrintBoard(board);

            //4. Define an end game counter
            int endCounter = 0;

            //5. Start Game Loop
            while (victory == false)
            {
                //5.1 O's Turn
                TurnO(board);
                PrintBoard(board);

                //5.1.1 Check for Victory
                victory = Victory(board);
                if (victory == true)
                {
                    C.WriteLine("'O', YOU WIN!");
                    return;
                }

                //5.2 Draw Condition
                if (endCounter == 4)    //this basically means, that after 4,5 rounds the game board must be full, so it ends
                {
                    C.WriteLine("ITS A DRAW!");
                    return;
                }

                //5.3 X's Turn
                TurnX(board);
                PrintBoard(board);
                victory = Victory(board);

                //5.3.1 Check for Victory
                victory = Victory(board);
                if (victory == true)
                {
                    C.WriteLine("'X', YOU WIN!");
                    return;
                }

                //5.4 count the end counter up
                endCounter++;

            }
        }
    }
}
