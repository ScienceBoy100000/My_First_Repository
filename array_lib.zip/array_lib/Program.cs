﻿using System.Diagnostics.Metrics;

namespace array_lib;
// Teamwork mit Dominik Adam und Helene Redl

class IntArrayTools
{
    //Calc an Average
    public static float Average(int[] array)
    {
        float sum = 0;

        foreach (int number in array)   //sum up all numbers
        {
            sum += number;
        }

        float average = sum / array.Length; //divide sum by array length

        return average; //return the average as float 
    }

    //Search for the minimum
    public static int Min(int[] array)  
    {
        int min = array[0]; //get the minimum started, set the first element as temporary minimum

        foreach (int number in array)   //go on the search
        {
            if (number < min)   //replace minimum each time something smaller is found
            {
                min = number;
            }
        }

        return min;
    }

    //Search for the maximum
    public static int Max(int[] array)  
    {
        int min = array[0]; //get the maximum started, set the first element as temporary maximum

        foreach (int number in array)   //go on the search
        {
            if (number > min)   //replace maximum each time something bigger is found
            {
                min = number;
            }
        }

        return min;
    }

    //Combine two arrays
    public static int[] ConCat(int[] array1, int[] array2)  
    {
        int[] combo = new int[array1.Length + array2.Length];   //make array with length of both
        int counter = 0;    //set a counter 

        foreach (int number1 in array1) //put numbers into the combo array
        {
            combo[counter] = number1;   //assign this element the value of that element
            counter++;
        }

        foreach (int number2 in array2) //continue to put numbers into combo where we left off
        {
            combo[counter] = number2;   //assign this element the value of that element
            counter++;
        }

        return combo;
    }

    //Reverse an array
    public static int[] Reverse(int[] array)
    {
        int[] reversed = new int[array.Length]; //prepare a reversed array
        int counter = reversed.Length - 1;  //be careful, the "-1" because length != index

        foreach (int number in array)   //make reversed order
        {
            reversed[counter] = number; //assign this element the value of that element
            counter--;
        }

        return reversed;
    }
}

class Program
{
    static void Main(string[] args)
    {
        //Test Data
        int[] test1 = [1, 2, 3, 4, 5];
        int[] test2 = [6, 7, 8, 9, 10];

        //1. Testing "Average"
        Console.WriteLine(IntArrayTools.Average(test1));

        //2. Testing "Minimum"
        Console.WriteLine(IntArrayTools.Min(test1));

        //3. Testing "Maximum"
        Console.WriteLine(IntArrayTools.Max(test1));

        //4. Testing "ConCat"
        int[] comboArray = IntArrayTools.ConCat(test1, test2);

        foreach (int number in comboArray)  //Print the array
        {
            Console.Write($"{number} ");
        } 

        //Make some space
        Console.WriteLine();

        //5. Testing "Reverse"
        int[] reverseArray = IntArrayTools.Reverse(test1);

        foreach (int number in reverseArray)    //print the array
        {
            Console.Write($"{number} ");
        } 
    }
}
